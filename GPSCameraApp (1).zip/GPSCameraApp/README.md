# Kamera GPS Profesional — Form Custom (Nama, Koptan, Keterangan, Ketinggian)

Aplikasi Android: kamera dengan kontrol setara aplikasi kamera profesional,
plus watermark otomatis berisi data form custom (Nama, Koptan, Keterangan
hasil) plus koordinat GPS dan ketinggian (altitude). Foto disimpan ke galeri
(folder `Pictures/KameraGPS`).

## Fitur kamera profesional
- **Flash**: Off → Auto → On → Torch (senter menyala terus), otomatis
  disembunyikan/nonaktif kalau perangkat tidak punya lampu flash.
- **Ganti kamera depan/belakang** — otomatis dicegah kalau perangkat tidak
  punya kamera depan.
- **Zoom optik/digital** dengan gestur cubit (pinch-to-zoom) di layar,
  ditampilkan level zoom real-time (mis. `2.0x`).
- **Tap-to-focus** — ketuk titik mana pun di preview untuk fokus & exposure
  ke titik itu.
- **Slider exposure (EV compensation)** vertikal di sisi kanan layar untuk
  mencerahkan/menggelapkan hasil sebelum jepret. Rentang otomatis mengikuti
  kemampuan sensor tiap perangkat (ada yang lebih luas, ada yang sempit).
- **Grid rule-of-thirds** — bisa dinyalakan/dimatikan untuk bantu komposisi.
- **Rasio foto** 4:3 / 16:9, bisa diganti langsung dari tombol atas.
- **Timer jepret** Off / 3 detik / 10 detik dengan hitung mundur di layar.
- **Tombol volume** (naik/turun) bisa dipakai untuk memotret, seperti kamera
  bawaan HP.
- **Kompatibilitas berbagai perangkat Android**:
  - Bekerja dari Android 7.0 (API 24) ke atas.
  - Semua fitur hardware (flash, kamera depan, autofocus) ditandai
    `android:required="false"` di manifest supaya app tetap bisa dipasang di
    perangkat yang tidak punya salah satunya (misalnya tablet tanpa flash).
  - Pengecekan runtime: kalau perangkat sama sekali tidak punya kamera, app
    menutup diri dengan pesan yang jelas alih-alih crash.
  - Penyimpanan foto memakai `MediaStore` dengan penanganan berbeda untuk
    Android 9 ke bawah (izin `WRITE_EXTERNAL_STORAGE`) dan Android 10 ke atas
    (scoped storage, tanpa perlu izin tambahan).
  - CameraX menangani perbedaan orientasi sensor & rotasi antar merek HP
    secara otomatis (Samsung, Xiaomi, Oppo, dll sering beda-beda).

## Cara membuka di Android Studio
1. Buka Android Studio → **Open** → pilih folder `GPSCameraApp` ini.
2. Tunggu proses **Gradle Sync** selesai (butuh koneksi internet pertama kali
   untuk mengunduh dependency CameraX & Play Services Location).
3. Sambungkan HP Android (atau pakai emulator yang mendukung GPS) →
   klik **Run**.
4. Saat pertama jalan, aplikasi akan minta izin **Kamera** dan **Lokasi** —
   izinkan keduanya.

## Cara pakai
1. Atur pengaturan kamera di panel atas kalau perlu: flash, kamera
   depan/belakang, grid, rasio foto, timer.
2. Cubit layar untuk zoom, atau ketuk satu titik untuk fokus ke situ.
   Geser slider di kanan layar untuk atur exposure (terang/gelap).
3. Isi kolom **Nama**, **Koptan**, dan **Keterangan** di bagian bawah layar.
4. Tunggu status GPS di kiri atas menampilkan koordinat & ketinggian
   (butuh beberapa detik, terutama di luar ruangan/sinyal GPS lebih akurat).
5. Tekan tombol **AMBIL FOTO** (atau tombol volume di HP).
6. Foto otomatis diberi watermark berisi semua data + waktu, lalu tersimpan
   ke galeri.

## Struktur penting
- `MainActivity.kt` — semua logika: kamera (CameraX), lokasi
  (FusedLocationProviderClient, termasuk `location.altitude`), penulisan
  watermark ke bitmap (Canvas), dan penyimpanan ke `MediaStore`.
- `activity_main.xml` — preview kamera + kartu form isian + tombol capture.

## Build APK online (tanpa install Android Studio) via GitHub Actions
Project ini sudah dilengkapi file `.github/workflows/build.yml` yang otomatis
meng-compile APK di server GitHub setiap kali kode di-push — gratis, tidak
perlu install apa pun di komputer.

1. Extract isi zip ini di komputer.
2. Buat akun gratis di [github.com](https://github.com) kalau belum punya.
3. Klik **New repository** → beri nama (mis. `kamera-gps`) → **jangan**
   centang "Add a README file" → **Create repository**.
4. Di halaman repo kosong, klik link **uploading an existing file** →
   seret (drag & drop) **semua isi** folder `GPSCameraApp` (bukan foldernya
   sendiri, tapi isi di dalamnya: `app/`, `.github/`, `build.gradle`, dst) →
   klik **Commit changes**.
5. Buka tab **Actions** di repo tersebut. Workflow "Build APK" akan otomatis
   berjalan (kalau tidak, klik **Run workflow** secara manual).
6. Tunggu sampai muncul tanda centang hijau (±3-5 menit) → klik proses yang
   selesai tersebut → scroll ke bagian **Artifacts** → unduh
   `KameraGPS-debug-apk.zip`.
7. Extract zip itu → di dalamnya ada file `app-debug.apk` yang tinggal
   dikirim ke HP Android dan diinstal langsung (aktifkan dulu "Izinkan dari
   sumber tidak dikenal" di pengaturan HP kalau diminta).

*Catatan: ini APK debug (untuk uji coba). Kalau nanti mau dipublikasikan ke
Play Store, perlu proses "signing" dengan keystore sendiri — bisa ditanyakan
kalau sudah sampai tahap itu.*

## Catatan & pengembangan lanjut (opsional)
- **ISO/shutter speed manual**: Fitur ini sengaja tidak dimasukkan karena
  butuh Camera2 API level rendah yang dukungannya sangat berbeda-beda antar
  merek HP (banyak yang membatasi akses manual demi menjaga kualitas
  otomatis). Exposure compensation (slider EV) yang sudah ada adalah cara
  paling stabil untuk mengatur terang/gelap di hampir semua perangkat.
- **Akurasi ketinggian**: GPS ponsel biasanya memberi altitude relatif
  terhadap ellipsoid WGS84, bukan permukaan laut — bisa selisih beberapa
  puluh meter dari altitude sebenarnya. Untuk data yang lebih presisi bisa
  ditambahkan koreksi geoid atau sensor barometer bila HP mendukung.
- **Riwayat data**: saat ini setiap foto hanya disimpan sebagai file gambar.
  Kalau nanti dibutuhkan riwayat/tabel data (misalnya untuk diekspor ke CSV
  atau disinkronkan ke aplikasi web monitoring pH tanah), bisa ditambahkan
  Room Database untuk menyimpan Nama, Koptan, Keterangan, Lat, Lon,
  Ketinggian, dan path foto setiap kali capture.
- **Custom kolom form**: kolom Nama/Koptan/Keterangan mudah ditambah atau
  diganti sesuai kebutuhan — cukup tambahkan `TextInputLayout` baru di
  `activity_main.xml` dan sertakan nilainya di fungsi `takePhoto()` dan
  `addWatermark()` pada `MainActivity.kt`.
