package com.example.gpscamera

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Overlay garis grid 3x3 (rule of thirds) di atas preview kamera.
 * Tidak menyentuh gambar hasil foto — murni bantuan komposisi di layar.
 */
class GridOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val linePaint = Paint().apply {
        color = 0x80FFFFFF.toInt()
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // 2 garis vertikal
        canvas.drawLine(w / 3f, 0f, w / 3f, h, linePaint)
        canvas.drawLine(2 * w / 3f, 0f, 2 * w / 3f, h, linePaint)

        // 2 garis horizontal
        canvas.drawLine(0f, h / 3f, w, h / 3f, linePaint)
        canvas.drawLine(0f, 2 * h / 3f, w, 2 * h / 3f, linePaint)
    }
}
